 AOS.init({

     easing: 'ease-in-out-sine',

     //once: true,

     duration: 1000,

 });

 $(window).scroll(function() {

     if ($(this).scrollTop() > 50) {

         $('.navbar-expand-lg').addClass('is-fixed');

     } else {

         $('.navbar-expand-lg').removeClass('is-fixed');

     }

 });


$('.main-hero .owl-carousel').owlCarousel({
 autoplay:500,
 loop:true,
 hover:false,
 dots: true,
 items:1,
    nav:false,
	
    
	
}) 



		$('.blog-section .owl-carousel').owlCarousel({

 autoplay:500,

 loop:true, margin:20,

 hover:false,

 dots: true,

 

    nav:false,

	

    responsive:{

        0:{

            items:1

        },

		 480:{

            items:2

        },

        600:{

            items:2

        },

		768:{

            items:3

        },

        1000:{

            items:3

        }

		

    } 

	

})

 	


